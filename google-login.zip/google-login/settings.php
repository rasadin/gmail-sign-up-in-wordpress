<?php 
// Configuration
$client_id = '921674505908-c4m01ls8r4q2b5v71969jtbacrauau3p.apps.googleusercontent.com';
$client_secret = '99JyqkD1BzBHcDgtK5DvD6n3';
$redirect_url = 'http://localhost/google-login';